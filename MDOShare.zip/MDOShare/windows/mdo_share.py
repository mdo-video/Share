import math
import threading
import time
from tkinter import filedialog

import customtkinter as ctk
import tkinter as tk

import _version
import updater
from netshare import Engine

BG, SIDE, SURF, SURF2 = "#0E0F14", "#12131A", "#181A22", "#232634"
ACC, ACC2, MUTED, TRACK = "#6B4EFF", "#A78BFF", "#9AA0B4", "#2A2D3C"


def mix(c1, c2, a):
    p = lambda c: [int(c[i:i + 2], 16) for i in (1, 3, 5)]
    r = [round(x * a + y * (1 - a)) for x, y in zip(p(c1), p(c2))]
    return "#%02x%02x%02x" % tuple(r)


def fmt(b):
    if b >= 1 << 30:
        return f"{b / (1 << 30):.1f} GB".replace(".", ",")
    if b >= 1 << 20:
        return f"{b / (1 << 20):.1f} MB".replace(".", ",")
    return f"{b // 1024} KB"


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        self.title("MDO Share")
        self.geometry("1040x640")
        self.minsize(900, 560)
        self.configure(fg_color=BG)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.info = None
        self.hit, self.cards = [], {}
        self.pages, self.navbtns = {}, {}
        self._sidebar()
        self.main = ctk.CTkFrame(self, fg_color=BG)
        self.main.grid(row=0, column=1, sticky="nsew", padx=32, pady=28)
        self.main.grid_columnconfigure(0, weight=1)
        self.main.grid_rowconfigure(1, weight=1)
        self._banner()
        self._home()
        self._history()
        self._settings()
        self.show("Home")
        self.engine = Engine(lambda: self.after(0, self.refresh), self.ask_accept)
        self.engine.start()
        self._tick()
        self.check_update(silent=True)

    # ---- layout ----
    def _sidebar(self):
        side = ctk.CTkFrame(self, fg_color=SIDE, corner_radius=0, width=200)
        side.grid(row=0, column=0, sticky="nsw")
        side.grid_propagate(False)
        ctk.CTkLabel(side, text="MDO Share", font=ctk.CTkFont(size=20, weight="bold")).pack(
            anchor="w", padx=24, pady=(28, 20))
        for name in ("Home", "Cronologia", "Impostazioni"):
            b = ctk.CTkButton(side, text=name, height=44, corner_radius=16, anchor="w",
                              fg_color="transparent", hover_color=SURF2, text_color=MUTED,
                              command=lambda n=name: self.show(n))
            b.pack(fill="x", padx=14, pady=3)
            self.navbtns[name] = b

    def _banner(self):
        self.banner = ctk.CTkFrame(self.main, fg_color=ACC, corner_radius=20)
        self.banner.grid_columnconfigure(0, weight=1)
        self.banner_label = ctk.CTkLabel(self.banner, text="", font=ctk.CTkFont(weight="bold"))
        self.banner_label.grid(row=0, column=0, sticky="w", padx=18, pady=14)
        self.banner_btn = ctk.CTkButton(self.banner, text="Aggiorna", width=110, height=40,
                                        corner_radius=14, fg_color="white", text_color=ACC,
                                        hover_color="#E8E4FF", command=self.do_update)
        self.banner_btn.grid(row=0, column=1, padx=14)
        self.bar = ctk.CTkProgressBar(self.banner, progress_color="white", fg_color=ACC2)
        self.bar.set(0)

    def _page(self, name):
        f = ctk.CTkFrame(self.main, fg_color=BG)
        f.grid(row=1, column=0, sticky="nsew")
        self.pages[name] = f
        return f

    def _home(self):
        f = self._page("Home")
        f.grid_columnconfigure(1, weight=1)
        left = ctk.CTkFrame(f, fg_color=BG)
        left.grid(row=0, column=0, sticky="n", padx=(0, 32))
        ctk.CTkLabel(left, text="Dispositivi vicini", font=ctk.CTkFont(size=22, weight="bold")).pack(anchor="w")
        self.hint = ctk.CTkLabel(left, text="", text_color=MUTED)
        self.hint.pack(anchor="w", pady=(2, 16))
        self.radar = tk.Canvas(left, width=300, height=300, bg=BG, highlightthickness=0, cursor="hand2")
        self.radar.pack()
        self.radar.bind("<Button-1>", self._click)
        self.right = ctk.CTkFrame(f, fg_color=BG)
        self.right.grid(row=0, column=1, sticky="new")
        ctk.CTkLabel(self.right, text="Trasferimenti", font=ctk.CTkFont(size=22, weight="bold")).pack(anchor="w", pady=(0, 14))
        self.empty = ctk.CTkLabel(self.right, text="Nessun trasferimento", text_color=MUTED)
        self.empty.pack(anchor="w")

    def _history(self):
        f = self._page("Cronologia")
        ctk.CTkLabel(f, text="Cronologia", font=ctk.CTkFont(size=22, weight="bold")).pack(anchor="w")
        ctk.CTkLabel(f, text="I trasferimenti recenti sono nella Home", text_color=MUTED).pack(anchor="w")

    def _settings(self):
        f = self._page("Impostazioni")
        ctk.CTkLabel(f, text="Impostazioni", font=ctk.CTkFont(size=22, weight="bold")).pack(anchor="w", pady=(0, 16))
        card = ctk.CTkFrame(f, fg_color=SURF, corner_radius=24)
        card.pack(fill="x")
        ctk.CTkLabel(card, text=f"Versione {_version.VERSION}", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=18, pady=(16, 0))
        self.status = ctk.CTkLabel(card, text="", text_color=MUTED)
        self.status.pack(anchor="w", padx=18)
        ctk.CTkButton(card, text="Controlla aggiornamenti", height=44, corner_radius=16, fg_color=ACC,
                      command=lambda: self.check_update(silent=False)).pack(anchor="w", padx=18, pady=16)

    def show(self, name):
        self.pages[name].tkraise()
        for n, b in self.navbtns.items():
            b.configure(fg_color=ACC if n == name else "transparent",
                        text_color="white" if n == name else MUTED)

    # ---- radar ----
    def _tick(self):
        c, t = self.radar, time.time()
        peers = self.engine.peer_list()
        hint = "Tocca un dispositivo per inviare un file" if peers else "Cerco dispositivi sulla stessa rete Wi-Fi..."
        if hint != self.hint.cget("text"):
            self.hint.configure(text=hint)
        c.delete("all")
        for k in (1, 2, 3):
            r = 140 * k / 3.2
            c.create_oval(150 - r, 150 - r, 150 + r, 150 + r, outline=mix(ACC, BG, 0.18))
        for i in range(3):
            f = ((t / 3) + i / 3) % 1
            r = 140 * f
            c.create_oval(150 - r, 150 - r, 150 + r, 150 + r, outline=mix(ACC, BG, 0.5 * (1 - f)), width=2)
        c.create_oval(120, 120, 180, 180, fill=ACC, outline="")
        self.hit = []
        for i, p in enumerate(peers[:6]):
            a = math.radians(i * 137.5 - 60)
            x, y = 150 + 100 * math.cos(a), 150 + 100 * math.sin(a)
            c.create_oval(x - 24, y - 24, x + 24, y + 24, fill=SURF2, outline=ACC2, width=2)
            c.create_text(x, y + 38, text=p["name"][:14], fill="white", font=("Segoe UI", 9, "bold"))
            self.hit.append((x, y, p))
        self.after(33, self._tick)

    def _click(self, e):
        for x, y, p in self.hit:
            if (e.x - x) ** 2 + (e.y - y) ** 2 <= 26 ** 2:
                for path in filedialog.askopenfilenames(title=f"Invia a {p['name']}"):
                    self.engine.send(p, path)
                return

    # ---- trasferimenti ----
    def _new_card(self, t):
        c = ctk.CTkFrame(self.right, fg_color=SURF, corner_radius=24)
        c.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(c, text=t["name"], font=ctk.CTkFont(size=15, weight="bold")).grid(row=0, column=0, sticky="w", padx=18, pady=(14, 0))
        info = ctk.CTkLabel(c, text="", text_color=MUTED)
        info.grid(row=1, column=0, sticky="w", padx=18)
        pb = ctk.CTkProgressBar(c, progress_color=ACC2, fg_color=TRACK, height=8)
        pb.grid(row=2, column=0, sticky="ew", padx=18, pady=(8, 16))
        return {"frame": c, "info": info, "pb": pb}

    def refresh(self):
        shown = self.engine.transfers[:6]
        ids = [t["id"] for t in shown]
        for tid in list(self.cards):
            if tid not in ids:
                self.cards.pop(tid)["frame"].destroy()
        changed = False
        for t in shown:
            if t["id"] not in self.cards:
                self.cards[t["id"]] = self._new_card(t)
                changed = True
            c = self.cards[t["id"]]
            who = f"Da {t['peer']}" if t["incoming"] else f"A {t['peer']}"
            c["info"].configure(text=f"{fmt(t['size'])} · {who} · {t['state']}")
            c["pb"].set(1 if t["state"] == "Completato" else (t["done"] / t["size"] if t["size"] else 0))
        if changed:
            for t in shown:
                self.cards[t["id"]]["frame"].pack_forget()
                self.cards[t["id"]]["frame"].pack(fill="x", pady=7)
        if shown:
            self.empty.pack_forget()
        else:
            self.empty.pack(anchor="w")

    def ask_accept(self, frm, name, size):
        """Chiamata da un thread di rete: mostra il popup e attende la risposta."""
        ev, res = threading.Event(), [False]

        def build():
            w = ctk.CTkToplevel(self)
            w.title("MDO Share")
            w.configure(fg_color=SURF2)
            w.geometry("360x220")
            w.resizable(False, False)
            w.attributes("-topmost", True)
            ctk.CTkLabel(w, text=f"{frm} vuole inviarti", text_color=ACC2,
                         font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=24, pady=(24, 4))
            ctk.CTkLabel(w, text=f"{name}\n{fmt(size)}", justify="left", wraplength=310).pack(anchor="w", padx=24)
            row = ctk.CTkFrame(w, fg_color="transparent")
            row.pack(side="bottom", fill="x", padx=24, pady=24)

            def done(v):
                res[0] = v
                ev.set()
                w.destroy()
            ctk.CTkButton(row, text="Accetta", height=44, corner_radius=16, fg_color=ACC,
                          command=lambda: done(True)).pack(side="left", expand=True, fill="x", padx=(0, 6))
            ctk.CTkButton(row, text="Rifiuta", height=44, corner_radius=16, fg_color="transparent",
                          border_width=1, border_color="#3A3F55",
                          command=lambda: done(False)).pack(side="left", expand=True, fill="x", padx=(6, 0))
            w.protocol("WM_DELETE_WINDOW", lambda: done(False))
        self.after(0, build)
        ev.wait(60)
        return res[0]

    # ---- aggiornamenti ----
    def check_update(self, silent):
        def work():
            info = updater.check()
            self.after(0, lambda: self._checked(info, silent))
        if not silent:
            self.status.configure(text="Controllo in corso...")
        threading.Thread(target=work, daemon=True).start()

    def _checked(self, info, silent):
        self.info = info
        if info:
            self.banner_label.configure(text=f"Aggiornamento disponibile · v{info['version']}")
            self.banner.grid(row=0, column=0, sticky="ew", pady=(0, 16))
        if not silent:
            self.status.configure(text=f"Disponibile la versione {info['version']}" if info else "Sei aggiornato")

    def do_update(self):
        self.banner_btn.configure(state="disabled")
        self.bar.grid(row=1, column=0, columnspan=2, sticky="ew", padx=18, pady=(0, 14))

        def work():
            try:
                path = updater.download(self.info, lambda p: self.after(0, lambda: self.bar.set(p)))
                if updater.apply_and_restart(path):
                    self.after(0, self.destroy)
                else:
                    self.after(0, lambda: self.banner_label.configure(text="Scaricato: l'aggiornamento funziona solo con l'exe"))
            except Exception:
                self.after(0, lambda: self.banner_label.configure(text="Download non riuscito"))
                self.after(0, lambda: self.banner_btn.configure(state="normal"))
        threading.Thread(target=work, daemon=True).start()


if __name__ == "__main__":
    App().mainloop()

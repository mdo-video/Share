import threading
import time

import customtkinter as ctk
import tkinter as tk

import _version
import updater

BG, SIDE, SURF, SURF2 = "#0E0F14", "#12131A", "#181A22", "#232634"
ACC, ACC2, MUTED, TRACK = "#6B4EFF", "#A78BFF", "#9AA0B4", "#2A2D3C"


def mix(c1, c2, a):
    p = lambda c: [int(c[i:i + 2], 16) for i in (1, 3, 5)]
    r = [round(x * a + y * (1 - a)) for x, y in zip(p(c1), p(c2))]
    return "#%02x%02x%02x" % tuple(r)


class App(ctk.CTk):
    def __init__(self):
        super().__init__()
        ctk.set_appearance_mode("dark")
        self.title("MDO Share")
        self.geometry("1040x640")
        self.minsize(900, 560)
        self.configure(fg_color=BG)
        self.grid_columnconfigure(1, weight=1)
        self.grid_rowconfigure(0, weight=1)
        self.info = None
        self.pages, self.navbtns = {}, {}
        self._sidebar()
        self.main = ctk.CTkFrame(self, fg_color=BG)
        self.main.grid(row=0, column=1, sticky="nsew", padx=32, pady=28)
        self.main.grid_columnconfigure(0, weight=1)
        self.main.grid_rowconfigure(1, weight=1)
        self._banner()
        self._home()
        self._history()
        self._settings()
        self.show("Home")
        self._tick()
        self.check_update(silent=True)

    # ---- layout ----
    def _sidebar(self):
        side = ctk.CTkFrame(self, fg_color=SIDE, corner_radius=0, width=200)
        side.grid(row=0, column=0, sticky="nsw")
        side.grid_propagate(False)
        ctk.CTkLabel(side, text="MDO Share", font=ctk.CTkFont(size=20, weight="bold")).pack(
            anchor="w", padx=24, pady=(28, 20))
        for name in ("Home", "Cronologia", "Impostazioni"):
            b = ctk.CTkButton(side, text=name, height=44, corner_radius=16, anchor="w",
                              fg_color="transparent", hover_color=SURF2, text_color=MUTED,
                              command=lambda n=name: self.show(n))
            b.pack(fill="x", padx=14, pady=3)
            self.navbtns[name] = b

    def _banner(self):
        self.banner = ctk.CTkFrame(self.main, fg_color=ACC, corner_radius=20)
        self.banner.grid_columnconfigure(0, weight=1)
        self.banner_label = ctk.CTkLabel(self.banner, text="", font=ctk.CTkFont(weight="bold"))
        self.banner_label.grid(row=0, column=0, sticky="w", padx=18, pady=14)
        self.banner_btn = ctk.CTkButton(self.banner, text="Aggiorna", width=110, height=40,
                                        corner_radius=14, fg_color="white", text_color=ACC,
                                        hover_color="#E8E4FF", command=self.do_update)
        self.banner_btn.grid(row=0, column=1, padx=14)
        self.bar = ctk.CTkProgressBar(self.banner, progress_color="white", fg_color=ACC2)
        self.bar.set(0)

    def _page(self, name):
        f = ctk.CTkFrame(self.main, fg_color=BG)
        f.grid(row=1, column=0, sticky="nsew")
        self.pages[name] = f
        return f

    def _home(self):
        f = self._page("Home")
        f.grid_columnconfigure(1, weight=1)
        left = ctk.CTkFrame(f, fg_color=BG)
        left.grid(row=0, column=0, sticky="n", padx=(0, 32))
        ctk.CTkLabel(left, text="Dispositivi vicini", font=ctk.CTkFont(size=22, weight="bold")).pack(anchor="w")
        ctk.CTkLabel(left, text="Ricerca in corso", text_color=MUTED).pack(anchor="w", pady=(2, 16))
        self.radar = tk.Canvas(left, width=300, height=300, bg=BG, highlightthickness=0)
        self.radar.pack()
        right = ctk.CTkFrame(f, fg_color=BG)
        right.grid(row=0, column=1, sticky="new")
        ctk.CTkLabel(right, text="Trasferimenti", font=ctk.CTkFont(size=22, weight="bold")).pack(anchor="w", pady=(0, 14))
        # dati demo
        self._card(right, "Clip_01.mov", "2,4 GB · 62 MB/s", 0.74)
        self._card(right, "Foto_uscita.zip", "Completato · hash verificato", 1.0)

    def _card(self, parent, name, info, value):
        c = ctk.CTkFrame(parent, fg_color=SURF, corner_radius=24)
        c.pack(fill="x", pady=7)
        c.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(c, text=name, font=ctk.CTkFont(size=15, weight="bold")).grid(row=0, column=0, sticky="w", padx=18, pady=(14, 0))
        ctk.CTkLabel(c, text=info, text_color=MUTED).grid(row=1, column=0, sticky="w", padx=18)
        pb = ctk.CTkProgressBar(c, progress_color=ACC2, fg_color=TRACK, height=8)
        pb.set(value)
        pb.grid(row=2, column=0, sticky="ew", padx=18, pady=(8, 16))

    def _history(self):
        f = self._page("Cronologia")
        ctk.CTkLabel(f, text="Cronologia", font=ctk.CTkFont(size=22, weight="bold")).pack(anchor="w")
        ctk.CTkLabel(f, text="Nessun trasferimento", text_color=MUTED).pack(anchor="w")

    def _settings(self):
        f = self._page("Impostazioni")
        ctk.CTkLabel(f, text="Impostazioni", font=ctk.CTkFont(size=22, weight="bold")).pack(anchor="w", pady=(0, 16))
        card = ctk.CTkFrame(f, fg_color=SURF, corner_radius=24)
        card.pack(fill="x")
        ctk.CTkLabel(card, text=f"Versione {_version.VERSION}", font=ctk.CTkFont(weight="bold")).pack(anchor="w", padx=18, pady=(16, 0))
        self.status = ctk.CTkLabel(card, text="", text_color=MUTED)
        self.status.pack(anchor="w", padx=18)
        ctk.CTkButton(card, text="Controlla aggiornamenti", height=44, corner_radius=16, fg_color=ACC,
                      command=lambda: self.check_update(silent=False)).pack(anchor="w", padx=18, pady=16)

    def show(self, name):
        self.pages[name].tkraise()
        for n, b in self.navbtns.items():
            b.configure(fg_color=ACC if n == name else "transparent",
                        text_color="white" if n == name else MUTED)

    # ---- radar ----
    def _tick(self):
        c, t = self.radar, time.time()
        c.delete("all")
        for k in (1, 2, 3):
            r = 140 * k / 3.2
            c.create_oval(150 - r, 150 - r, 150 + r, 150 + r, outline=mix(ACC, BG, 0.18))
        for i in range(3):
            f = ((t / 3) + i / 3) % 1
            r = 140 * f
            c.create_oval(150 - r, 150 - r, 150 + r, 150 + r, outline=mix(ACC, BG, 0.5 * (1 - f)), width=2)
        c.create_oval(120, 120, 180, 180, fill=ACC, outline="")
        c.create_oval(222, 40, 270, 88, fill=SURF2, outline=ACC2, width=2)  # dispositivo demo
        c.create_text(246, 102, text="Pixel di Marco", fill="white", font=("Segoe UI", 9, "bold"))
        self.after(33, self._tick)

    # ---- aggiornamenti ----
    def check_update(self, silent):
        def work():
            info = updater.check()
            self.after(0, lambda: self._checked(info, silent))
        if not silent:
            self.status.configure(text="Controllo in corso...")
        threading.Thread(target=work, daemon=True).start()

    def _checked(self, info, silent):
        self.info = info
        if info:
            self.banner_label.configure(text=f"Aggiornamento disponibile · v{info['version']}")
            self.banner.grid(row=0, column=0, sticky="ew", pady=(0, 16))
        if not silent:
            self.status.configure(text=f"Disponibile la versione {info['version']}" if info else "Sei aggiornato")

    def do_update(self):
        self.banner_btn.configure(state="disabled")
        self.bar.grid(row=1, column=0, columnspan=2, sticky="ew", padx=18, pady=(0, 14))

        def work():
            try:
                path = updater.download(self.info, lambda p: self.after(0, lambda: self.bar.set(p)))
                if updater.apply_and_restart(path):
                    self.after(0, self.destroy)
                else:
                    self.after(0, lambda: self.banner_label.configure(text="Scaricato: l'aggiornamento funziona solo con l'exe"))
            except Exception:
                self.after(0, lambda: self.banner_label.configure(text="Download non riuscito"))
                self.after(0, lambda: self.banner_btn.configure(state="normal"))
        threading.Thread(target=work, daemon=True).start()


if __name__ == "__main__":
    App().mainloop()

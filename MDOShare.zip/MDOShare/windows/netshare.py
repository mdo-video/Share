import json
import os
import socket
import threading
import time
import uuid

UDP_PORT, TCP_PORT = 47474, 47475
CHUNK = 256 * 1024


def downloads_dir():
    d = os.path.join(os.path.expanduser("~"), "Downloads", "MDO Share")
    os.makedirs(d, exist_ok=True)
    return d


def safe(name):
    return "".join("_" if ch in '\\/:*?"<>|' else ch for ch in name)


def unique(path):
    base, ext = os.path.splitext(path)
    n = 1
    while os.path.exists(path):
        path = f"{base} ({n}){ext}"
        n += 1
    return path


def read_line(s):
    b = bytearray()
    while len(b) < 8192:
        x = s.recv(1)
        if not x or x == b"\n":
            break
        b += x
    return b.decode("utf-8", "replace")


class Engine:
    """Scoperta UDP (47474) + trasferimento TCP (47475), compatibile con l'app Android."""

    def __init__(self, on_change, ask_accept):
        self.id = str(uuid.uuid4())
        self.name = socket.gethostname()
        self.peers, self.transfers = {}, []
        self.lock = threading.Lock()
        self.on_change, self.ask_accept = on_change, ask_accept
        self._last = 0.0

    def start(self):
        for fn in (self._announce, self._listen, self._serve, self._expire):
            threading.Thread(target=fn, daemon=True).start()

    # ---- scoperta ----
    def _broadcasts(self):
        out = {"255.255.255.255"}
        try:
            for ip in socket.gethostbyname_ex(socket.gethostname())[2]:
                p = ip.split(".")
                if len(p) == 4 and not ip.startswith("127."):
                    out.add(".".join(p[:3] + ["255"]))
        except Exception:
            pass
        return out

    def _announce(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        msg = json.dumps({"id": self.id, "name": self.name, "type": "pc", "port": TCP_PORT}).encode()
        while True:
            for a in self._broadcasts():
                try:
                    s.sendto(msg, (a, UDP_PORT))
                except Exception:
                    pass
            time.sleep(2)

    def _listen(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("", UDP_PORT))
        except OSError:
            return
        while True:
            try:
                data, addr = s.recvfrom(2048)
                j = json.loads(data.decode())
                if j["id"] == self.id:
                    continue
                with self.lock:
                    self.peers[j["id"]] = {"id": j["id"], "name": j["name"], "type": j.get("type", ""),
                                           "ip": addr[0], "port": int(j["port"]), "seen": time.time()}
                self.on_change()
            except Exception:
                pass

    def _expire(self):
        while True:
            time.sleep(2)
            with self.lock:
                old = [k for k, p in self.peers.items() if time.time() - p["seen"] > 7]
                for k in old:
                    del self.peers[k]
            if old:
                self.on_change()

    def peer_list(self):
        with self.lock:
            return list(self.peers.values())

    # ---- ricezione ----
    def _serve(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("", TCP_PORT))
        except OSError:
            return
        s.listen(5)
        while True:
            c, _ = s.accept()
            threading.Thread(target=self._receive, args=(c,), daemon=True).start()

    def _receive(self, c):
        try:
            with c:
                c.settimeout(60)
                h = json.loads(read_line(c))
                name, size, frm = safe(h["name"]), int(h["size"]), h.get("from", "?")
                if not self.ask_accept(frm, name, size):
                    c.sendall(b"NO\n")
                    return
                c.sendall(b"OK\n")
                t = self._new(name, size, True, frm)
                try:
                    path = unique(os.path.join(downloads_dir(), name))
                    done = 0
                    with open(path, "wb") as f:
                        while done < size:
                            data = c.recv(min(CHUNK, size - done))
                            if not data:
                                raise EOFError
                            f.write(data)
                            done += len(data)
                            self._prog(t, done)
                    c.sendall(b"DONE\n")
                    self._fin(t, "Completato")
                except Exception:
                    self._fin(t, "Errore")
        except Exception:
            pass

    # ---- invio ----
    def send(self, peer, path):
        threading.Thread(target=self._send, args=(peer, path), daemon=True).start()

    def _send(self, peer, path):
        name, size = os.path.basename(path), os.path.getsize(path)
        t = self._new(name, size, False, peer["name"])
        try:
            with socket.create_connection((peer["ip"], peer["port"]), timeout=5) as s:
                s.settimeout(90)
                s.sendall((json.dumps({"name": name, "size": size, "from": self.name}) + "\n").encode())
                if read_line(s) != "OK":
                    self._fin(t, "Rifiutato")
                    return
                s.settimeout(30)
                done = 0
                with open(path, "rb") as f:
                    while True:
                        chunk = f.read(CHUNK)
                        if not chunk:
                            break
                        s.sendall(chunk)
                        done += len(chunk)
                        self._prog(t, done)
                self._fin(t, "Completato" if read_line(s) == "DONE" else "Errore")
        except Exception:
            self._fin(t, "Errore")

    # ---- stato trasferimenti ----
    def _new(self, name, size, incoming, peer):
        t = {"id": str(uuid.uuid4()), "name": name, "size": size, "done": 0,
             "incoming": incoming, "peer": peer, "state": "In corso"}
        with self.lock:
            self.transfers.insert(0, t)
        self.on_change()
        return t

    def _prog(self, t, done):
        t["done"] = done
        if time.time() - self._last > 0.1 or done >= t["size"]:
            self._last = time.time()
            self.on_change()

    def _fin(self, t, state):
        t["state"] = state
        self.on_change()

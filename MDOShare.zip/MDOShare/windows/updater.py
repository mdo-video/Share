import os
import subprocess
import sys
import tempfile

import requests

import _version

ASSET = "MDOShare.exe"


def _headers(accept):
    h = {"Accept": accept}
    if _version.TOKEN:
        h["Authorization"] = f"Bearer {_version.TOKEN}"
    return h


def current():
    return int(_version.VERSION.rsplit(".", 1)[1])


def check():
    """Ritorna {'version', 'url'} se c'e' una versione piu' nuova, altrimenti None."""
    if not _version.REPO:
        return None
    try:
        r = requests.get(
            f"https://api.github.com/repos/{_version.REPO}/releases/latest",
            headers=_headers("application/vnd.github+json"), timeout=15)
        if r.status_code != 200:
            return None
        j = r.json()
        code = int(j["tag_name"].rsplit(".", 1)[1])
        if code <= current():
            return None
        for a in j["assets"]:
            if a["name"] == ASSET:
                return {"version": j["tag_name"].lstrip("v"), "url": a["url"]}
    except Exception:
        return None
    return None


def download(info, progress):
    dest = os.path.join(tempfile.gettempdir(), "MDOShare_new.exe")
    with requests.get(info["url"], headers=_headers("application/octet-stream"),
                      stream=True, timeout=30) as r:
        r.raise_for_status()
        total = int(r.headers.get("content-length", 0))
        done = 0
        with open(dest, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                f.write(chunk)
                done += len(chunk)
                if total:
                    progress(done / total)
    return dest


def apply_and_restart(new_exe):
    """Sostituisce l'exe in uso con quello nuovo e riavvia. Solo per l'exe compilato."""
    if not getattr(sys, "frozen", False):
        return False
    exe = sys.executable
    bat = os.path.join(tempfile.gettempdir(), "mdoshare_update.bat")
    script = (
        "@echo off\r\n"
        "timeout /t 2 /nobreak >nul\r\n"
        ":retry\r\n"
        f'move /y "{new_exe}" "{exe}" >nul 2>&1\r\n'
        "if errorlevel 1 (\r\n  timeout /t 1 /nobreak >nul\r\n  goto retry\r\n)\r\n"
        f'start "" "{exe}"\r\n'
        'del "%~f0"\r\n'
    )
    with open(bat, "w") as f:
        f.write(script)
    subprocess.Popen(["cmd", "/c", bat], creationflags=0x08000000 | 0x00000008)
    return True

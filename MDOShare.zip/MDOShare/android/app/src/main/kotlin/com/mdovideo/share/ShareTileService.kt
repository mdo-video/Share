package com.mdovideo.share

import android.app.StatusBarManager
import android.content.ComponentName
import android.content.Context
import android.graphics.drawable.Icon
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

class ShareTileService : TileService() {
    override fun onStartListening() {
        Engine.start(applicationContext)
        refresh()
    }

    override fun onClick() {
        Engine.setVisible(applicationContext, !Engine.visible)
        refresh()
    }

    private fun refresh() {
        val t = qsTile ?: return
        t.label = "MDO Share"
        t.state = if (Engine.visible) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
        if (Build.VERSION.SDK_INT >= 29) t.subtitle = if (Engine.visible) "Visibile" else "Nascosto"
        t.updateTile()
    }
}

/** Android 13+: chiede di aggiungere il toggle ai pulsanti rapidi. */
fun requestTile(ctx: Context) {
    if (Build.VERSION.SDK_INT >= 33) {
        val sbm = ctx.getSystemService(StatusBarManager::class.java)
        sbm.requestAddTileService(
            ComponentName(ctx, ShareTileService::class.java), "MDO Share",
            Icon.createWithResource(ctx, R.drawable.ic_tile), ctx.mainExecutor
        ) { _ -> }
    }
}

package com.mdovideo.share

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.EOFException
import java.io.File
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID

data class Peer(val id: String, val name: String, val type: String, val ip: String, val port: Int, val seen: Long)

data class Transfer(
    val id: String, val name: String, val size: Long, val done: Long,
    val incoming: Boolean, val peer: String, val state: String
)

class Incoming(val peer: String, val name: String, val size: Long) {
    val decision = CompletableDeferred<Boolean>()
}

/** Scoperta (UDP broadcast, porta 47474) + trasferimento (TCP, porta 47475) sulla stessa rete Wi-Fi. */
object Engine {
    private const val UDP_PORT = 47474
    private const val TCP_PORT = 47475

    private lateinit var ctx: Context
    private var started = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val myId = UUID.randomUUID().toString()
    private val myName: String = Build.MODEL ?: "Android"

    var peers by mutableStateOf(listOf<Peer>())
        private set
    var transfers by mutableStateOf(listOf<Transfer>())
        private set
    var incoming by mutableStateOf<Incoming?>(null)
        private set

    @Synchronized
    fun start(c: Context) {
        if (started) return
        started = true
        ctx = c.applicationContext
        val wm = ctx.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val lock = wm.createMulticastLock("mdoshare")
        lock.setReferenceCounted(false)
        lock.acquire()
        scope.launch { announce() }
        scope.launch { listen() }
        scope.launch { serve() }
        scope.launch { expire() }
    }

    // ---------- scoperta ----------
    private suspend fun announce() {
        val msg = JSONObject().put("id", myId).put("name", myName).put("type", "android")
            .put("port", TCP_PORT).toString().toByteArray()
        val addr = InetAddress.getByName("255.255.255.255")
        val s = DatagramSocket()
        s.broadcast = true
        while (true) {
            try { s.send(DatagramPacket(msg, msg.size, addr, UDP_PORT)) } catch (e: Exception) { }
            delay(2000)
        }
    }

    private fun listen() {
        val s = try {
            DatagramSocket(null).apply { reuseAddress = true; bind(InetSocketAddress(UDP_PORT)) }
        } catch (e: Exception) { return }
        val buf = ByteArray(2048)
        while (true) {
            val p = DatagramPacket(buf, buf.size)
            try { s.receive(p) } catch (e: Exception) { break }
            try {
                val j = JSONObject(String(p.data, 0, p.length))
                val id = j.getString("id")
                if (id == myId) continue
                val ip = p.address.hostAddress ?: continue
                val peer = Peer(id, j.getString("name"), j.getString("type"), ip, j.getInt("port"), System.currentTimeMillis())
                setPeers { list -> list.filter { it.id != id } + peer }
            } catch (e: Exception) { }
        }
    }

    private suspend fun expire() {
        while (true) {
            delay(2000)
            val now = System.currentTimeMillis()
            setPeers { list -> list.filter { now - it.seen < 7000 } }
        }
    }

    @Synchronized
    private fun setPeers(f: (List<Peer>) -> List<Peer>) { peers = f(peers) }

    // ---------- ricezione ----------
    private fun serve() {
        val ss = try {
            ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(TCP_PORT)) }
        } catch (e: Exception) { return }
        while (true) {
            val c = try { ss.accept() } catch (e: Exception) { break }
            scope.launch { receive(c) }
        }
    }

    private suspend fun receive(c: Socket) {
        try {
            c.use {
                c.soTimeout = 30000
                val inp = BufferedInputStream(c.getInputStream())
                val out = c.getOutputStream()
                val h = JSONObject(readLine(inp))
                val name = h.getString("name").replace(Regex("[\\\\/:*?\"<>|]"), "_")
                val size = h.getLong("size")
                val from = h.optString("from", "?")
                val req = Incoming(from, name, size)
                incoming = req
                val ok = withTimeoutOrNull(60000) { req.decision.await() } ?: false
                incoming = null
                if (!ok) {
                    out.write("NO\n".toByteArray()); out.flush()
                    return
                }
                out.write("OK\n".toByteArray()); out.flush()
                val t = newTransfer(name, size, true, from)
                try {
                    store(name, inp, size) { d -> progress(t.id, d) }
                    out.write("DONE\n".toByteArray()); out.flush()
                    finish(t.id, "Completato")
                } catch (e: Exception) {
                    finish(t.id, "Errore")
                }
            }
        } catch (e: Exception) {
            incoming = null
        }
    }

    private fun store(name: String, inp: InputStream, size: Long, onProgress: (Long) -> Unit) {
        if (Build.VERSION.SDK_INT >= 29) {
            val cv = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, name)
                put(MediaStore.Downloads.RELATIVE_PATH, "Download/MDO Share")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            val r = ctx.contentResolver
            val uri = r.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv) ?: throw IOException("insert")
            try {
                r.openOutputStream(uri)!!.use { pump(inp, it, size, onProgress) }
                val ready = ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }
                r.update(uri, ready, null, null)
            } catch (e: Exception) {
                r.delete(uri, null, null)
                throw e
            }
        } else {
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: ctx.filesDir
            File(dir, name).outputStream().use { pump(inp, it, size, onProgress) }
        }
    }

    // ---------- invio ----------
    fun send(peer: Peer, uri: Uri) {
        scope.launch {
            val (name, size) = describe(uri)
            val t = newTransfer(name, size, false, peer.name)
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(peer.ip, peer.port), 5000)
                    s.soTimeout = 90000
                    val out = BufferedOutputStream(s.getOutputStream())
                    val header = JSONObject().put("name", name).put("size", size).put("from", myName)
                    out.write((header.toString() + "\n").toByteArray()); out.flush()
                    if (readLine(s.getInputStream()) != "OK") {
                        finish(t.id, "Rifiutato")
                        return@launch
                    }
                    s.soTimeout = 30000
                    ctx.contentResolver.openInputStream(uri)!!.use { pump(it, out, size) { d -> progress(t.id, d) } }
                    out.flush()
                    finish(t.id, if (readLine(s.getInputStream()) == "DONE") "Completato" else "Errore")
                }
            } catch (e: Exception) {
                finish(t.id, "Errore")
            }
        }
    }

    private fun describe(uri: Uri): Pair<String, Long> {
        var name = "file"
        var size = 0L
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni) ?: name
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        return Pair(name, size)
    }

    // ---------- utilita' ----------
    private fun readLine(i: InputStream): String {
        val b = ByteArrayOutputStream()
        while (b.size() < 8192) {
            val x = i.read()
            if (x < 0 || x == 10) break
            b.write(x)
        }
        return b.toString("UTF-8")
    }

    private fun pump(inp: InputStream, out: OutputStream, size: Long, onProgress: (Long) -> Unit) {
        val buf = ByteArray(256 * 1024)
        var done = 0L
        var last = 0L
        while (done < size) {
            val n = inp.read(buf, 0, minOf(buf.size.toLong(), size - done).toInt())
            if (n < 0) throw EOFException()
            out.write(buf, 0, n)
            done += n
            val now = System.currentTimeMillis()
            if (now - last > 100 || done == size) {
                onProgress(done)
                last = now
            }
        }
    }

    @Synchronized
    private fun newTransfer(name: String, size: Long, incoming: Boolean, peer: String): Transfer {
        val t = Transfer(UUID.randomUUID().toString(), name, size, 0L, incoming, peer, "In corso")
        transfers = listOf(t) + transfers
        return t
    }

    @Synchronized
    private fun progress(id: String, done: Long) {
        transfers = transfers.map { if (it.id == id) it.copy(done = done) else it }
    }

    @Synchronized
    private fun finish(id: String, state: String) {
        transfers = transfers.map { if (it.id == id) it.copy(state = state) else it }
    }
}

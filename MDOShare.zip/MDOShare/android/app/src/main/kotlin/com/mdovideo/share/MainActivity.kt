package com.mdovideo.share

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.util.Locale
import kotlin.math.cos
import kotlin.math.sin

val Bg = Color(0xFF0E0F14)
val Surf = Color(0xFF181A22)
val Accent = Color(0xFF6B4EFF)
val Accent2 = Color(0xFFA78BFF)
val Muted = Color(0xFF9AA0B4)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Engine.start(applicationContext)
        val transparent = android.graphics.Color.TRANSPARENT
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(transparent),
            navigationBarStyle = SystemBarStyle.dark(transparent)
        )
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Accent, onPrimary = Color.White, secondary = Accent2,
                    background = Bg, surface = Surf,
                    onBackground = Color(0xFFF2F3F7), onSurface = Color(0xFFF2F3F7)
                )
            ) { App() }
        }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableStateOf(0) }
    var update by remember { mutableStateOf<UpdateInfo?>(null) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var status by remember { mutableStateOf("") }
    var pending by remember { mutableStateOf<Peer?>(null) }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        pending?.let { p -> uris.forEach { Engine.send(p, it) } }
    }
    val version = remember { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "" }

    LaunchedEffect(Unit) { update = Updater.check(ctx) }

    Surface(Modifier.fillMaxSize(), color = Bg) {
        Column(Modifier.systemBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp)) {
            update?.let { info ->
                UpdateBanner(info, progress) {
                    scope.launch {
                        progress = 0f
                        try {
                            val f = Updater.download(ctx, info) { p -> progress = p }
                            Updater.install(ctx, f)
                        } catch (e: Exception) {
                            status = "Download non riuscito"
                        }
                        progress = null
                    }
                }
            }
            Box(Modifier.weight(1f)) {
                when (tab) {
                    0 -> Home(Engine.peers, Engine.transfers.take(3)) { pending = it; pick.launch("*/*") }
                    1 -> History(Engine.transfers)
                    else -> SettingsScreen(version, status) {
                        scope.launch {
                            status = "Controllo in corso..."
                            val u = Updater.check(ctx)
                            update = u
                            status = if (u == null) "Sei aggiornato" else "Disponibile la versione ${u.versionName}"
                        }
                    }
                }
            }
            BottomBar(tab) { tab = it }
            Engine.incoming?.let { IncomingDialog(it) }
        }
    }
}

@Composable
fun Home(peers: List<Peer>, transfers: List<Transfer>, onPeer: (Peer) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Condividi", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(
            if (peers.isEmpty()) "Cerco dispositivi sulla stessa rete Wi-Fi..." else "Tocca un dispositivo per inviare un file",
            color = Muted, fontSize = 14.sp
        )
        Spacer(Modifier.height(8.dp))
        Radar(peers, onPeer, Modifier.size(340.dp).align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
        transfers.forEach {
            TransferCard(it)
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun History(transfers: List<Transfer>) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Text("Cronologia", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        if (transfers.isEmpty()) Text("Nessun trasferimento", color = Muted, fontSize = 14.sp)
        Spacer(Modifier.height(12.dp))
        transfers.forEach {
            TransferCard(it)
            Spacer(Modifier.height(8.dp))
        }
    }
}

@Composable
fun Radar(peers: List<Peer>, onPeer: (Peer) -> Unit, modifier: Modifier = Modifier) {
    val t = rememberInfiniteTransition(label = "radar")
    val p by t.animateFloat(0f, 1f, infiniteRepeatable(tween(3000, easing = LinearEasing), RepeatMode.Restart), label = "p")
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val r = size.minDimension / 2
            for (k in 1..3) drawCircle(Accent.copy(alpha = 0.18f), radius = r * k / 3.2f, style = Stroke(1.dp.toPx()))
            for (i in 0..2) {
                val f = (p + i / 3f) % 1f
                drawCircle(Accent.copy(alpha = 0.5f * (1f - f)), radius = r * f, style = Stroke(2.dp.toPx()))
            }
            drawCircle(Accent.copy(alpha = 0.12f), radius = r * 0.33f)
        }
        Box(Modifier.size(72.dp).clip(CircleShape).background(Accent))
        peers.take(6).forEachIndexed { i, peer ->
            val a = Math.toRadians(i * 137.5 - 60)
            Device(peer, (100 * cos(a)).dp, (100 * sin(a)).dp, onPeer)
        }
    }
}

@Composable
fun Device(peer: Peer, x: Dp, y: Dp, onClick: (Peer) -> Unit) {
    Column(Modifier.offset(x, y).clickable { onClick(peer) }.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(52.dp).clip(CircleShape).background(Color(0xFF232634)).border(2.dp, Accent2, CircleShape))
        Text(
            peer.name, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, maxLines = 1,
            overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 96.dp).padding(top = 6.dp)
        )
    }
}

fun fmt(b: Long): String = when {
    b >= (1L shl 30) -> String.format(Locale.ITALY, "%.1f GB", b / 1073741824.0)
    b >= (1L shl 20) -> String.format(Locale.ITALY, "%.1f MB", b / 1048576.0)
    else -> String.format(Locale.ITALY, "%d KB", b / 1024)
}

@Composable
fun TransferCard(t: Transfer) {
    val progress = if (t.size > 0) (t.done.toFloat() / t.size).coerceIn(0f, 1f) else 0f
    val who = if (t.incoming) "Da ${t.peer}" else "A ${t.peer}"
    val ring = if (t.state == "Completato") 1f else progress
    val label = when (t.state) {
        "Completato" -> "OK"
        "In corso" -> "${(progress * 100).toInt()}%"
        else -> "!"
    }
    Surface(color = Surf, shape = RoundedCornerShape(24.dp)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(56.dp).clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(Accent, Color(0xFF1E1B3A))))
            )
            Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
                Text(t.name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${fmt(t.size)} · $who · ${t.state}", fontSize = 13.sp, color = Muted)
            }
            Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val w = 5.dp.toPx()
                    val s = Size(size.width - w, size.height - w)
                    val tl = Offset(w / 2, w / 2)
                    drawArc(Color(0xFF2A2D3C), 0f, 360f, false, tl, s, style = Stroke(w))
                    drawArc(Accent2, -90f, 360f * ring, false, tl, s, style = Stroke(w, cap = StrokeCap.Round))
                }
                Text(label, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun IncomingDialog(req: Incoming) {
    AlertDialog(
        onDismissRequest = { req.decision.complete(false) },
        containerColor = Surf,
        shape = RoundedCornerShape(24.dp),
        title = { Text("${req.peer} vuole inviarti un file") },
        text = { Text("${req.name} · ${fmt(req.size)}") },
        confirmButton = { Button(onClick = { req.decision.complete(true) }) { Text("Accetta") } },
        dismissButton = { TextButton(onClick = { req.decision.complete(false) }) { Text("Rifiuta") } }
    )
}

@Composable
fun UpdateBanner(info: UpdateInfo, progress: Float?, onClick: () -> Unit) {
    Surface(color = Accent, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Aggiornamento disponibile", fontWeight = FontWeight.Bold)
                    Text("Versione ${info.versionName}", fontSize = 13.sp)
                }
                Button(
                    onClick = onClick, enabled = progress == null,
                    colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Accent)
                ) { Text("Aggiorna") }
            }
            if (progress != null) {
                LinearProgressIndicator(
                    progress = { progress }, color = Color.White, trackColor = Color(0x55FFFFFF),
                    modifier = Modifier.fillMaxWidth().padding(top = 12.dp)
                )
            }
        }
    }
}

@Composable
fun Placeholder(title: String, text: String) {
    Column {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(text, color = Muted, fontSize = 14.sp)
    }
}

@Composable
fun SettingsScreen(version: String, status: String, onCheck: () -> Unit) {
    Column {
        Text("Impostazioni", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Surface(color = Surf, shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp)) {
                Text("Versione $version", fontWeight = FontWeight.SemiBold)
                if (status.isNotEmpty()) Text(status, color = Muted, fontSize = 13.sp)
                Spacer(Modifier.height(12.dp))
                Button(onClick = onCheck, modifier = Modifier.height(48.dp)) { Text("Controlla aggiornamenti") }
            }
        }
    }
}

@Composable
fun BottomBar(selected: Int, onSelect: (Int) -> Unit) {
    Surface(color = Surf, shape = RoundedCornerShape(28.dp), modifier = Modifier.fillMaxWidth().padding(top = 8.dp)) {
        Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            listOf("Home", "Cronologia", "Impostazioni").forEachIndexed { i, label ->
                val on = i == selected
                Button(
                    onClick = { onSelect(i) },
                    modifier = Modifier.height(48.dp),
                    shape = RoundedCornerShape(20.dp),
                    contentPadding = PaddingValues(horizontal = 14.dp),
                    elevation = null,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (on) Accent else Color.Transparent,
                        contentColor = if (on) Color.White else Muted
                    )
                ) { Text(label, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
            }
        }
    }
}

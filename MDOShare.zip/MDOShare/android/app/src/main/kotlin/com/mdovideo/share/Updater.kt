package com.mdovideo.share

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.core.content.FileProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

data class UpdateInfo(val code: Long, val versionName: String, val assetUrl: String)

object Updater {
    private const val APK_NAME = "MDOShare.apk"

    private fun open(url: String, accept: String, follow: Boolean = true): HttpURLConnection {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 30000
        c.instanceFollowRedirects = follow
        c.setRequestProperty("Accept", accept)
        if (BuildConfig.UPDATE_TOKEN.isNotEmpty() && url.startsWith("https://api.github.com")) {
            c.setRequestProperty("Authorization", "Bearer ${BuildConfig.UPDATE_TOKEN}")
        }
        return c
    }

    suspend fun check(ctx: Context): UpdateInfo? = withContext(Dispatchers.IO) {
        if (BuildConfig.REPO.isEmpty()) return@withContext null
        try {
            val c = open("https://api.github.com/repos/${BuildConfig.REPO}/releases/latest", "application/vnd.github+json")
            if (c.responseCode != 200) return@withContext null
            val j = JSONObject(c.inputStream.bufferedReader().readText())
            val tag = j.getString("tag_name")
            val code = tag.substringAfterLast('.').toLongOrNull() ?: return@withContext null
            val current = ctx.packageManager.getPackageInfo(ctx.packageName, 0).longVersionCode
            if (code <= current) return@withContext null
            val assets = j.getJSONArray("assets")
            for (i in 0 until assets.length()) {
                val a = assets.getJSONObject(i)
                if (a.getString("name") == APK_NAME) {
                    return@withContext UpdateInfo(code, tag.removePrefix("v"), a.getString("url"))
                }
            }
            null
        } catch (e: Exception) {
            null
        }
    }

    suspend fun download(ctx: Context, info: UpdateInfo, onProgress: (Float) -> Unit): File =
        withContext(Dispatchers.IO) {
            val first = open(info.assetUrl, "application/octet-stream", follow = false)
            val location = first.getHeaderField("Location")
            val src = if (first.responseCode in 300..399 && location != null) {
                first.disconnect()
                open(location, "application/octet-stream")
            } else first
            val dir = File(ctx.cacheDir, "updates").apply { mkdirs() }
            val out = File(dir, APK_NAME)
            val total = src.contentLengthLong
            var done = 0L
            src.inputStream.use { input ->
                out.outputStream().use { output ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        output.write(buf, 0, n)
                        done += n
                        if (total > 0) onProgress(done.toFloat() / total)
                    }
                }
            }
            out
        }

    fun install(ctx: Context, apk: File) {
        if (!ctx.packageManager.canRequestPackageInstalls()) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
            return
        }
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", apk)
        ctx.startActivity(
            Intent(Intent.ACTION_VIEW)
                .setDataAndType(uri, "application/vnd.android.package-archive")
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }
}
